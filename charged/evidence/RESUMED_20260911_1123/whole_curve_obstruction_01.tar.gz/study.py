"""Author-side finite unaware-curve analysis. Writes only under this directory."""
from pathlib import Path
from functools import lru_cache
from collections import Counter
import datetime, hashlib, json, signal, sys, time, traceback

HERE = Path(__file__).resolve().parent

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def top(weights, k):
    return sum(sorted(weights, reverse=True)[:max(0, k)])

def solve(case, deadline):
    w, edges, r = case['works'], case['edges'], case['r']
    n, K = len(w), len(w) + r
    assert n and all(isinstance(x, int) and x > 0 for x in w)
    pred = [0] * n
    for u, v in edges:
        assert 0 <= u < v < n
        pred[v] |= 1 << u
    full = (1 << n) - 1
    nodes = [{'done': True}]
    counters = Counter()
    force = case.get('force')

    @lru_cache(None)
    def safe(S, k, ell):
        future = [x for i, x in enumerate(w) if S >> i & 1]
        completed = [x for i, x in enumerate(w) if not S >> i & 1]
        old = all(ell + top(future, m) <= top(w, k+m)
                  for m in range(len(future)+1))
        new = ell <= top(completed, k)
        assert old == new, (S, k, ell, old, new)
        counters['safe_states'] += 1
        return old

    def add(front, curve, node):
        counters['candidate_curves'] += 1
        if any(all(a <= b for a, b in zip(c, curve)) for c, _ in front):
            return
        front[:] = [(c, t) for c, t in front
                    if not all(a <= b for a, b in zip(curve, c))]
        idx = len(nodes)
        nodes.append(node)
        front.append((curve, idx))

    @lru_cache(None)
    def f(S, t, k, ell):
        if time.monotonic() >= deadline:
            raise TimeoutError('fixed run deadline')
        if not S:
            return (((0,) * (K+1), 0),)
        front = []
        assert t or safe(S, k, ell)
        mode_required = (force['mode'] if force and
                         [S, t, k, ell] == force['state'] else None)
        for i, wi in enumerate(w):
            if not S >> i & 1 or pred[i] & S:
                continue
            T = S ^ (1 << i)
            if t:
                for a, ai in f(T, t, 0, 0):
                    for z, zi in f(S, t-1, 0, 0):
                        curve = tuple(wi + (a[b] if b == 0 else max(a[b], z[b-1]))
                                      for b in range(K+1))
                        add(front, curve, {'job': i, 'mode': 'cheap', 'match': ai, 'mismatch': zi})
            else:
                if mode_required != 'fresh':
                    for a, ai in f(T, 0, k, ell):
                        for z, zi in f(T, 0, k+1, ell+wi):
                            curve = tuple(wi + (a[b] if b == 0 else max(a[b], wi+z[b-1]))
                                          for b in range(K+1))
                            add(front, curve, {'job': i, 'mode': 'cached', 'match': ai, 'mismatch': zi})
                if mode_required != 'cached' and safe(T, k, ell+wi):
                    for a, ai in f(T, 0, k, ell+wi):
                        add(front, tuple(wi+x for x in a), {'job': i, 'mode': 'fresh', 'next': ai})
        assert front, (case['id'], S, t, k, ell)
        return tuple(sorted(front))

    start = tuple(case.get('start', [full, r, 0, 0]))
    result = f(*start)
    assert result and all(all(x <= y for x, y in zip(c, c[1:])) for c, _ in result)
    curves = [list(c) for c, _ in result]
    coordinate_min = [min(c[b] for c in curves) for b in range(K+1)]
    used = {0}
    def collect(idx):
        if idx in used:
            return
        used.add(idx)
        node = nodes[idx]
        for key in ('next', 'match', 'mismatch'):
            if key in node:
                collect(node[key])
    for _, idx in result:
        collect(idx)
    packet = {'case': case, 'start': start,
              'policies': [{'curve': c, 'root': idx} for c, idx in result],
              'nodes': {str(i): nodes[i] for i in sorted(used)}}
    return {'curves': curves, 'coordinate_min': coordinate_min,
            'one_policy_attains_coordinate_min': coordinate_min in curves,
            'front_size': len(result), 'states': f.cache_info().currsize,
            'counts': dict(counters)}, packet

def interpret(packet, deadline):
    """Walk every outcome path; do not use DP combination or Pareto pruning."""
    case, nodes = packet['case'], packet['nodes']
    w, r = case['works'], case['r']
    n, K = len(w), len(w)+r
    S0, t0, k0, ell0 = packet['start']
    prefix_writes = 0 if t0 else r + k0
    prefix_calls = n-S0.bit_count() + r-t0
    summaries = []
    for policy in packet['policies']:
        measured, witnesses = [-1]*(K+1), [None]*(K+1)
        paths = 0
        def walk(idx, S, writes, work, protection, calls, trace):
            nonlocal paths
            if time.monotonic() >= deadline:
                raise TimeoutError('fixed run deadline during path interpretation')
            assert protection <= top(w, max(prefix_writes+writes-r, 0))
            node = nodes[str(idx)]
            if node.get('done'):
                assert S == 0 and prefix_calls+calls <= n+r
                paths += 1
                for b in range(writes, K+1):
                    if work > measured[b]:
                        measured[b], witnesses[b] = work, trace
                return
            i, mode = node['job'], node['mode']
            assert S >> i & 1
            assert all(not S >> u & 1 for u, v in case['edges'] if v == i)
            T, wi = S ^ (1 << i), w[i]
            if mode == 'fresh':
                walk(node['next'], T, writes, work+wi, protection+wi, calls+1,
                     trace+[[i, mode]])
            else:
                walk(node['match'], T, writes, work+wi, protection, calls+1,
                     trace+[[i, mode, 'match']])
                walk(node['mismatch'], S if mode == 'cheap' else T,
                     writes+1, work+wi+(wi if mode == 'cached' else 0),
                     protection+(wi if mode == 'cached' else 0), calls+1,
                     trace+[[i, mode, 'mismatch']])
        walk(policy['root'], S0, 0, 0, ell0, 0, [])
        assert measured == list(policy['curve']), (measured, policy['curve'])
        summaries.append({'paths': paths, 'measured_curve': measured,
                          'maximizing_paths': witnesses})
    return summaries

def expected_control(case):
    w, r = case['works'], case['r']
    n, omega = len(w), sum(w)
    if case.get('control') == 'old_chain6':
        return [11, 15, 19, 21, 22, 22, 23, 24]
    if r == 0 and 'start' not in case:
        return [omega+top(w, b) for b in range(n+1)]
    if not case['edges']:
        a = sorted(w)
        return [omega+b*a[-1] if b <= r else omega +
                max(r*a[n-m]+top(w, m) for m in range(1, min(b-r,n)+1))
                for b in range(n+r+1)]

def main():
    tag = sys.argv[1]
    assert tag in ('01', '02')
    inputs = HERE / ('INPUTS'+tag+'.json')
    cases = json.loads(inputs.read_text())['cases']
    run_dir = HERE / ('run'+tag)
    run_dir.mkdir()
    started = datetime.datetime.now(datetime.timezone.utc)
    assert started.astimezone(datetime.timezone(datetime.timedelta(hours=9))).strftime('%H:%M') < '12:15'
    start = time.monotonic()
    deadline = start+80
    counts, front_counts, total_paths = Counter(), Counter(), 0
    with (run_dir/'RESULTS.jsonl').open('x') as raw:
        for case in cases:
            row = {'case': case, 'id': case['id']}
            try:
                result, packet = solve(case, deadline)
                # Save each selected representative before verification, including any failing one.
                filename = case['id']+'.json'
                with (run_dir/filename).open('x') as fh:
                    json.dump(packet, fh, separators=(',', ':'))
                    fh.write('\n')
                row.update(result, witness=filename)
                check = interpret(packet, deadline)
                expected = expected_control(case)
                if expected is not None:
                    row['control_expected'] = expected
                    assert result['curves'] == [expected], (result['curves'], expected)
                row.update(status='SUCCESS', path_checks=check)
                total_paths += sum(x['paths'] for x in check)
                front_counts[result['front_size']] += 1
            except TimeoutError as e:
                row.update(status='TIMEOUT', error=str(e))
            except AssertionError:
                row.update(status='FAILURE', error=traceback.format_exc())
            except Exception:
                row.update(status='INVALID', error=traceback.format_exc())
            counts[row['status']] += 1
            raw.write(json.dumps(row, separators=(',', ':'))+'\n')
            raw.flush()
    summary = {'started_utc': started.isoformat(),
               'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'seconds': time.monotonic()-start, 'planned': len(cases),
               'counts': dict(counts), 'front_sizes': dict(front_counts),
               'interpreted_paths': total_paths, 'input_sha256': digest(inputs),
               'script_sha256': digest(Path(__file__)),
               'raw_sha256': digest(run_dir/'RESULTS.jsonl'),
               'general_program_normal_form_claimed': False,
               'child_processes_started': 0}
    assert sum(counts.values()) == len(cases)
    with (run_dir/'SUMMARY.json').open('x') as fh:
        json.dump(summary, fh, indent=2)
        fh.write('\n')
    print(json.dumps(summary), flush=True)

if __name__ == '__main__':
    main()
