C145 reading bundle — Synthesizing Staged Updates between Verified Controllers

Keep main.pdf and supplementary_material.pdf in the same directory for relative cross-document links.
Main text: 18 pages; main PDF including references: 21 pages; integrated supplement: 87 pages.
These PDFs are exact copies of the selected C145 candidate files.
Release: https://github.com/research-artifact-archive/research-artifact/tree/fgducs-c145-20261004

The links printed inside the manuscript still cite the retained C143 supporting-material release. C145 adds only a 94-word opening Introduction paragraph; the supporting supplementary text, proofs and experimental evidence are unchanged. The C143 tag keeps its earlier main PDF. Use main.pdf in this bundle for C145.
