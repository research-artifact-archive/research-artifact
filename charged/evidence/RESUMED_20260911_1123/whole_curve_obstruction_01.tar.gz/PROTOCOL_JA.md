# Whole-curve obstruction: 結果前の限定検査規約

2026-09-11、著者側理論反証helper。SCIENTIFIC。最新POLICYとRESEARCH-30を確認。root唯一原稿writer。書込みはこのディレクトリ内だけ。12:15 JST以降新規runなし、12:20までに報告停止。CPU一process、各runは壁時計90秒未満（内部80秒、最終出力余裕10秒）、追加分担・Claude・人対象評価・課金・credit/reset禁止。

## 仮説と既存証拠

問う対象はV_r={Bを入力せず、すべての有限bについてQ<=n+rとL<=Top_(b-r)+(J)を同一方策で守るもの}におけるF(B)=inf_(P in V_r) sup_(E in E_B) W(P,E)。全BでF(B)を一方策が達成するかは一般正retry DAGで未解決。known-BごとにL capを変えた最適化はこの問題ではない。

既存causal_work_pareto_01/02/03は、r回失敗までcurrent-prepared cheap、その後はC可行なfresh/cachedを履歴依存で選ぶ限定クラスを調べた。5456 chain roots、216 DAG roots、12288 chain6 rootsはすべてroot曲線一本。chain6の35 rootsは二規則を改善しただけ。七job chain J=(2,1,1,1,4,3,6), r=1の途中状態(i=4,k=3,ell=3)には、fresh4開始の余剰曲線(0,3,9,...)とcached4開始の(0,4,7,...)がある。一般root反例ではない。r=0の全DAGと独立jobsの全rには全曲線達成定理があり、そこへの反例は実装/意味論誤りとして扱う。

H1: この既存七job途中状態はfull-rootへ直接運べず、他の履歴の最悪値に覆われる。全root曲線と当該状態の第一手をfresh/cachedに固定したroot曲線を比較し、具体的なマスキング値を得る。
H2: 途中状態の可到達性だけでは全体最悪値での活性性と第一手の不可回避性が足りない。必要な追加証明義務を明示する。
H3 (限定探索): 既存七jobのprefix仕事またはprefix長を変えた新規固定入力で、限定クラス内の非支配root曲線が複数になる可能性がある。見つからなくても同入力の再実行・母集団差替えをしない。

## 第1run: 既知例の新しい条件付き解析、計11単位

結果前にINPUTS01.jsonを別途固定する。全単位は以下。
1--3. 七job chain,r=1, fullroot: unconstrained / 当該(i=4,k=3,ell=3)でfresh固定 / cached固定。
4--6. 同じ残余状態: unconstrained / fresh固定 / cached固定。budget座標は残余bでありprefix実書込み4とは区別する。
7. 七job chain,r=0: 全DAG既知定理のnegative control。
8. 六job chain (2,4,1,1,2,1),r=1: 既存曲線と一致するreproduction control（新規発見とはしない）。
9--11. 独立jobs (1,2,4),r=0,1,2: 原稿の閉形式に一致するnegative controls。

各単位に全budget曲線、front size、状態数、代表方策DAGを保存。新しい条件下の検査であり旧rawを更新しない。方策curveの成分minがfrontにないときだけ限定クラスの全曲線達成不存在とする。r0/独立jobの不一致、空front、曲線非単調はFAILURE。期限到達はTIMEOUT、入力/実装例外はINVALIDとして全11行を出力。timeoutになった入力を再実行しない。

## 第2runの実施条件

第1runが意味論controlsを満たした場合のみ、別INPUTS02.jsonとPLAN02.jsonで新規の全入力を結果前に固定する。対象と変更理由、全分母、80秒の内部期限を明示する。旧結果なしを隠す再実行はしない。時間が足りなければ第2runを開始せず未実施と報告する。

## 手法・反証条件・限界

有限決定木AND/OR再帰でfuture b=0..n+rの曲線を保持し、成分ごとの支配除去のみ行う。枝の選択は観測後に独立、各方策はBを参照しない。安全条件は旧Cの全m不等式を実装し、新残余定理ell<=Top_k(D)との同値も確認する。全残余予算で同時にLを守る方策だけを入れる。出力方策は別の完全経路走査でQ/LとW曲線を評価する（同著者側、独立査読とは呼ばない）。

複数curveを発見しても、追加inspection・保持record等を含む一般programへのnormal formがなければ一般full-root反例と主張しない。既存状態で両first-action固定root curveが一致すれば直接のlift失敗の証拠になるが、全一般DAG存在定理にはしない。最終REPORT_JA.mdには短い確定結果または正確な未解決理由、全観測分母、全失敗/timeout/invalid、変更files、残process0を記録する。
