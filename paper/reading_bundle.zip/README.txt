Reading bundle — Synthesizing Staged Updates between Verified Controllers

Keep main.pdf and supplementary_material.pdf in the same directory for links between the two documents.

main.pdf: the main paper, with 18 pages of body text and 21 pages including references.
supplementary_material.pdf: the 87-page integrated supplement, containing Technical Appendix A–R and Supplement S1–S5, with reading routes, bookmarks and continuous page numbers.

Implementation, experimental evidence and reproduction instructions:
https://github.com/research-artifact-archive/research-artifact
