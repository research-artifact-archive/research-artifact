C143 manuscript and supplementary material
Release: fgducs-c143-20261004

Open main.pdf for the 18-page scientific body (21 pages including Data Availability and references).
Open supplementary_material.pdf for the 87-page integrated Technical Appendix A-R and Supplement S1-S5.
Keep both PDF files in the same directory so relative cross-document links resolve.
The supplement has linked reading routes, contents, bookmarks and continuous page numbers.

The selected C143 scientific body is unchanged. Artifact locations and reference information have been updated to the matching public release.
Source, evidence, complete index and reproduction instructions:
https://github.com/research-artifact-archive/research-artifact/tree/fgducs-c143-20261004
